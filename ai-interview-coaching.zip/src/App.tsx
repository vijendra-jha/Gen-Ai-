/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CandidateProfile, Question, Evaluation, AnswerSession, InterviewSession, Report } from './types';
import SetupForm from './components/SetupForm';
import InterviewConsole from './components/InterviewConsole';
import FeedbackWidget from './components/FeedbackWidget';
import ReportDashboard from './components/ReportDashboard';
import { Sparkles, Brain, AlertCircle, RefreshCcw, HelpCircle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const LOCAL_STORAGE_KEY = 'ai_interview_coach_session';

export default function App() {
  const [session, setSession] = useState<InterviewSession | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [currentEvaluation, setCurrentEvaluation] = useState<Evaluation | null>(null);
  const [isFollowUpActive, setIsFollowUpActive] = useState(false);
  const [activeFollowUpQuestion, setActiveFollowUpQuestion] = useState<Question | null>(null);
  const [errorText, setErrorText] = useState('');

  // Load active session from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSession(parsed);
      } catch (err) {
        console.error('Failed to parse saved session:', err);
      }
    }
  }, []);

  // Save session to local storage when state changes
  const saveSession = (newSession: InterviewSession | null) => {
    setSession(newSession);
    if (newSession) {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newSession));
    } else {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    }
  };

  // Step 1: Generate interview questions (Prompt 1)
  const handleStartInterview = async (profile: CandidateProfile) => {
    setIsGenerating(true);
    setErrorText('');
    try {
      const response = await fetch('/api/generate-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to generate interview questions.');
      }

      const data = await response.json();
      if (!data.questions || data.questions.length === 0) {
        throw new Error('No interview questions returned by the AI.');
      }

      const initialSession: InterviewSession = {
        id: `session_${Date.now()}`,
        profile,
        questions: data.questions,
        currentQuestionIndex: 0,
        answers: [],
        status: 'active',
        createdAt: Date.now()
      };

      saveSession(initialSession);
      setCurrentEvaluation(null);
      setIsFollowUpActive(false);
      setActiveFollowUpQuestion(null);
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || 'An error occurred while generating interview questions.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Step 2: Evaluate candidate answer (Prompt 2 + Prompt 3 + Prompt 4)
  const handleAnswerSubmit = async (answerText: string) => {
    if (!session) return;
    setIsEvaluating(true);
    setErrorText('');

    const activeQuestion = isFollowUpActive && activeFollowUpQuestion 
      ? activeFollowUpQuestion 
      : session.questions[session.currentQuestionIndex];

    try {
      // Assemble dialogue history to supply context to the LLM
      const previousContext = session.answers.map((item, idx) => `
        Question ${idx + 1}: ${item.question.question}
        Answer ${idx + 1}: ${item.answer}
      `).join('\n');

      const response = await fetch('/api/evaluate-answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: activeQuestion.question,
          answer: answerText,
          previousContext
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to evaluate answer.');
      }

      const evaluation: Evaluation = await response.json();

      // Save answer session locally
      const answerSession: AnswerSession = {
        question: activeQuestion,
        answer: answerText,
        evaluation,
        isFollowUp: isFollowUpActive,
        followUpToQuestion: isFollowUpActive ? session.questions[session.currentQuestionIndex].question : undefined
      };

      const updatedAnswers = [...session.answers, answerSession];
      const updatedSession: InterviewSession = {
        ...session,
        answers: updatedAnswers
      };

      saveSession(updatedSession);
      setCurrentEvaluation(evaluation);
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || 'An error occurred while submitting your response.');
    } finally {
      setIsEvaluating(false);
    }
  };

  // Step 3: Handle Skipping a Question
  const handleSkipQuestion = () => {
    if (!session) return;

    const activeQuestion = isFollowUpActive && activeFollowUpQuestion 
      ? activeFollowUpQuestion 
      : session.questions[session.currentQuestionIndex];

    const answerSession: AnswerSession = {
      question: activeQuestion,
      answer: '[Skipped / No Answer Provided]',
      isFollowUp: isFollowUpActive,
      followUpToQuestion: isFollowUpActive ? session.questions[session.currentQuestionIndex].question : undefined
    };

    const updatedAnswers = [...session.answers, answerSession];
    const updatedSession: InterviewSession = {
      ...session,
      answers: updatedAnswers
    };

    saveSession(updatedSession);
    handleNextQuestionDirect(updatedSession);
  };

  // Step 4: Handle Accept Probing follow-up challenge (Prompt 4 activation)
  const handleAnswerFollowUp = (followUpText: string) => {
    if (!session) return;

    // Create follow-up Question details
    const followUpObj: Question = {
      question: followUpText,
      category: 'Adaptive Follow-Up',
      difficulty: 'Hard',
      skills_tested: ['Deeper Reasoning', 'Critical System Design'],
      expected_topics: [],
      estimated_time: '2-3 minutes'
    };

    setActiveFollowUpQuestion(followUpObj);
    setIsFollowUpActive(true);
    setCurrentEvaluation(null); // Clear active feedback overlay to return to active console
  };

  // Step 5: Progress to next question or compile report
  const handleNextQuestionDirect = async (currentSessionState = session) => {
    if (!currentSessionState) return;

    // If follow-up was active, we complete it and return to core questions track
    if (isFollowUpActive) {
      setIsFollowUpActive(false);
      setActiveFollowUpQuestion(null);
    }

    const nextIndex = currentSessionState.currentQuestionIndex + 1;

    if (nextIndex < currentSessionState.questions.length) {
      // Move to next main question in sequence
      const updatedSession: InterviewSession = {
        ...currentSessionState,
        currentQuestionIndex: nextIndex
      };
      saveSession(updatedSession);
      setCurrentEvaluation(null);
    } else {
      // Completed all questions! Compile the report!
      await handleGenerateReport(currentSessionState);
    }
  };

  // Step 6: Generate final scorecard (Prompt 5)
  const handleGenerateReport = async (currentSessionState: InterviewSession) => {
    setIsGeneratingReport(true);
    setErrorText('');
    try {
      const response = await fetch('/api/generate-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile: currentSessionState.profile,
          answers: currentSessionState.answers
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to generate final interview report.');
      }

      const report: Report = await response.json();

      const completedSession: InterviewSession = {
        ...currentSessionState,
        status: 'completed',
        report
      };

      saveSession(completedSession);
      setCurrentEvaluation(null);
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || 'Failed to generate final performance report.');
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const handleRestart = () => {
    saveSession(null);
    setCurrentEvaluation(null);
    setIsFollowUpActive(false);
    setActiveFollowUpQuestion(null);
    setErrorText('');
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F4F4F4] flex flex-col font-sans selection:bg-[#38BDF8] selection:text-[#0A0A0A]">
      {/* Editorial Premium Header */}
      <header className="border-b border-[#2A2A2A] px-6 sm:px-10 py-6 flex justify-between items-end bg-[#0A0A0A] sticky top-0 z-40">
        <div className="flex flex-col cursor-pointer" onClick={handleRestart}>
          <span className="text-[9px] uppercase tracking-[0.3em] text-[#888] mb-1 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#38BDF8] animate-pulse"></span>
            System Active — v4.2
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif italic tracking-tight text-[#F4F4F4]">
            AI Interview Coach
          </h1>
        </div>

        {/* Right side Metadata & Control Bar */}
        <div className="flex gap-6 sm:gap-10 text-right items-end">
          {session && (
            <>
              <div className="hidden md:block text-left">
                <p className="text-[9px] uppercase tracking-widest text-[#888] mb-0.5">Candidate</p>
                <p className="text-xs font-medium text-[#F4F4F4]">{session.profile.name}</p>
              </div>
              <div className="hidden md:block text-left">
                <p className="text-[9px] uppercase tracking-widest text-[#888] mb-0.5">Target Role</p>
                <p className="text-xs font-medium italic text-[#F4F4F4]">{session.profile.role}</p>
              </div>
            </>
          )}
          <button
            type="button"
            id="btn-nav-restart"
            onClick={handleRestart}
            className="text-[10px] uppercase tracking-widest border border-[#444] px-4 py-2 hover:bg-[#F4F4F4] hover:text-[#0A0A0A] text-[#F4F4F4] transition-colors cursor-pointer font-semibold"
          >
            Reset Session
          </button>
        </div>
      </header>

      {/* Main Container Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 bg-[#0A0A0A]">
        {/* Global Error Banner */}
        {errorText && (
          <div className="max-w-4xl mx-auto bg-red-950/20 border border-red-900/60 text-red-300 p-4 rounded-xl text-xs sm:text-sm flex items-start gap-2.5 mb-6 shadow-xs animate-fadeIn relative">
            <AlertCircle className="w-5 h-5 mt-0.5 shrink-0 text-red-500" />
            <div className="flex-1 pr-6">
              <span className="font-bold">Execution Error:</span> {errorText}
            </div>
            <button
              onClick={() => setErrorText('')}
              className="absolute top-3 right-3 text-red-400 hover:text-red-300 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="space-y-6">
          {/* CASE 1: Setup View */}
          {!session && (
            <SetupForm onSubmit={handleStartInterview} isLoading={isGenerating} />
          )}

          {/* CASE 2: Active Interview Console */}
          {session && session.status === 'active' && !currentEvaluation && (
            <InterviewConsole
              question={isFollowUpActive && activeFollowUpQuestion ? activeFollowUpQuestion : session.questions[session.currentQuestionIndex]}
              isFollowUp={isFollowUpActive}
              onAnswerSubmit={handleAnswerSubmit}
              onSkipQuestion={handleSkipQuestion}
              currentIndex={session.currentQuestionIndex}
              totalQuestions={session.questions.length}
              isSubmitting={isEvaluating}
            />
          )}

          {/* CASE 3: Active Feedback diagnostics overlay */}
          {session && session.status === 'active' && currentEvaluation && (
            <FeedbackWidget
              evaluation={currentEvaluation}
              question={isFollowUpActive && activeFollowUpQuestion ? activeFollowUpQuestion : session.questions[session.currentQuestionIndex]}
              onNextQuestion={() => handleNextQuestionDirect()}
              onAnswerFollowUp={handleAnswerFollowUp}
              hasMoreQuestions={session.currentQuestionIndex < session.questions.length - 1}
            />
          )}

          {/* CASE 4: Complete Report Dashboard view */}
          {session && session.status === 'completed' && session.report && (
            <ReportDashboard
              report={session.report}
              profile={session.profile}
              answers={session.answers}
              onRestart={handleRestart}
            />
          )}

          {/* Floating Generating Report loader */}
          {isGeneratingReport && (
            <div className="fixed inset-0 bg-[#0A0A0A]/80 backdrop-blur-xs flex items-center justify-center z-50 p-4">
              <div className="bg-[#111111] border border-[#2A2A2A] p-8 rounded-3xl max-w-md w-full text-center shadow-2xl">
                <div className="relative inline-block mb-4">
                  <div className="w-16 h-16 border-4 border-[#2A2A2A] border-t-[#38BDF8] rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-[#38BDF8] animate-pulse" />
                  </div>
                </div>
                <h3 className="text-lg font-serif italic text-white mb-1">Compiling Profile Report</h3>
                <p className="text-xs text-slate-400 leading-normal font-sans px-4">
                  Gemini is aggregating scores, analyzing behavioral logs, and drafting your 7-day personalized Roadmap plan...
                </p>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Editorial Bottom Status Strip */}
      <footer className="border-t border-[#2A2A2A] bg-[#0A0A0A] text-[#888] py-6 text-center text-xs">
        <div className="max-w-7xl mx-auto px-6 sm:px-10 flex flex-col sm:flex-row justify-between items-center gap-3">
          <span className="text-[9px] font-bold uppercase tracking-[0.2em]">
            &copy; 2026 AI Interview Coach — OPTIMAL SKILL BENCHMARKING
          </span>
          <div className="flex items-center gap-6 font-mono text-[9px] uppercase tracking-widest">
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
              LLM Connected: Gemini 3.5 Flash
            </span>
            <span>Latency: 42ms</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
