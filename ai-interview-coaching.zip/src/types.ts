/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CandidateProfile {
  name: string;
  role: string;
  experienceLevel: 'Entry Level' | 'Mid Level' | 'Senior' | 'Lead / Manager';
  jobDescription: string;
  resumeSummary: string;
  interviewType: 'Technical' | 'Behavioral' | 'Mixed';
  questionCount: number;
}

export interface Question {
  question: string;
  category: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  skills_tested: string[];
  expected_topics: string[];
  estimated_time: string;
}

export interface Evaluation {
  overall_score: number;
  dimension_scores: {
    relevance: number;
    technical_accuracy: number;
    communication: number;
    completeness: number;
    problem_solving: number;
    confidence: number;
  };
  strengths: string[];
  weaknesses: string[];
  missing_points: string[];
  improvement_suggestions: string[];
  sample_better_answer: string;
  readiness_level: string;
  follow_up_question?: string;
  follow_up_purpose?: string;
  follow_up_difficulty?: string;
}

export interface AnswerSession {
  question: Question;
  answer: string;
  evaluation?: Evaluation;
  isFollowUp: boolean;
  followUpToQuestion?: string;
}

export interface ActionPlanDay {
  day: string;
  focus: string;
  tasks: string[];
}

export interface Report {
  overall_score: number;
  overall_rating: 'Excellent' | 'Good' | 'Average' | 'Needs Improvement';
  performance_breakdown: {
    technical_knowledge: string;
    communication_skills: string;
    problem_solving: string;
    confidence: string;
    behavioral_readiness: string;
  };
  key_strengths: string[];
  areas_to_improve: string[];
  recommended_resources: string[];
  hiring_recommendation: 'Strong Hire' | 'Hire' | 'Borderline' | 'Not Yet Ready';
  action_plan_7_day: ActionPlanDay[];
}

export interface InterviewSession {
  id: string;
  profile: CandidateProfile;
  questions: Question[];
  currentQuestionIndex: number;
  answers: AnswerSession[];
  status: 'setup' | 'active' | 'completed';
  report?: Report;
  createdAt: number;
}
