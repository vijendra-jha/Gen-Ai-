/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Evaluation, Question } from '../types';
import { CheckCircle2, AlertTriangle, BookOpen, Lightbulb, ArrowRight, CornerDownRight, Award, ChevronDown, ChevronUp } from 'lucide-react';
import { motion } from 'motion/react';

interface FeedbackWidgetProps {
  evaluation: Evaluation;
  question: Question;
  onNextQuestion: () => void;
  onAnswerFollowUp: (followUpQuestion: string) => void;
  hasMoreQuestions: boolean;
}

export default function FeedbackWidget({
  evaluation,
  question,
  onNextQuestion,
  onAnswerFollowUp,
  hasMoreQuestions
}: FeedbackWidgetProps) {
  const [showBetterAnswer, setShowBetterAnswer] = useState(false);

  // Score color helper for editorial dark background
  const getScoreColor = (score: number) => {
    if (score >= 9) return 'text-[#38BDF8] border-[#38BDF8]/40 bg-[#0F172A]';
    if (score >= 7) return 'text-[#38BDF8] border-[#38BDF8]/20 bg-[#0F172A]/50';
    if (score >= 5) return 'text-amber-400 border-amber-800/40 bg-amber-950/20';
    return 'text-[#E11D48] border-red-900/40 bg-red-950/20';
  };

  const getScoreProgressColor = (score: number) => {
    if (score >= 9) return 'bg-[#38BDF8]';
    if (score >= 7) return 'bg-[#38BDF8]';
    if (score >= 5) return 'bg-amber-500';
    return 'bg-[#E11D48]';
  };

  return (
    <div id="feedback-widget" className="max-w-4xl mx-auto space-y-8">
      {/* Upper score card and dimensions */}
      <div className="bg-[#111111] border border-[#2A2A2A] p-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-[#2A2A2A] pb-6 mb-6 gap-4">
          <div>
            <span className="text-[10px] font-mono text-[#888] uppercase tracking-[0.2em]">Diagnostic Metrics</span>
            <h2 className="text-3xl font-serif italic text-white mt-1">Real-Time Scorecard</h2>
          </div>
          {/* Large overall score pill */}
          <div className="flex items-center gap-3">
            <span className="text-[10px] text-[#888] uppercase tracking-widest font-mono">Readiness:</span>
            <div className={`text-xl font-bold font-mono px-4 py-2 border ${getScoreColor(evaluation.overall_score)} flex items-center gap-2`}>
              <Award className="w-4 h-4" />
              <span>{evaluation.overall_score}/10</span>
              <span className="text-[10px] uppercase tracking-widest font-mono">({evaluation.readiness_level})</span>
            </div>
          </div>
        </div>

        {/* 6 Grading dimensions list */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-5">
          {Object.entries(evaluation.dimension_scores).map(([dimension, score]) => (
            <div key={dimension} id={`dimension-${dimension}`} className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono uppercase tracking-wider text-[#CCC] capitalize">
                <span>{dimension.replace('_', ' ')}</span>
                <span>{score}/10</span>
              </div>
              <div className="w-full h-1 bg-[#222] overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${getScoreProgressColor(score)}`}
                  style={{ width: `${score * 10}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Strengths & Gaps (Split) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Key Strengths */}
        <div className="bg-[#111111] border border-[#2A2A2A] p-8">
          <h3 className="text-[11px] font-mono uppercase tracking-[0.2em] text-[#888] mb-4 flex items-center gap-2 border-b border-[#2A2A2A] pb-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            Core Strengths Demonstrated
          </h3>
          <ul className="space-y-3 text-sm text-[#CCC]">
            {evaluation.strengths.map((str, idx) => (
              <li key={idx} className="flex items-start gap-2.5">
                <span className="text-[#38BDF8] font-bold font-serif">•</span>
                <span>{str}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Gaps and Weaknesses */}
        <div className="bg-[#111111] border border-[#2A2A2A] p-8">
          <h3 className="text-[11px] font-mono uppercase tracking-[0.2em] text-[#888] mb-4 flex items-center gap-2 border-b border-[#2A2A2A] pb-3">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            Areas For Improvement
          </h3>
          <ul className="space-y-3 text-sm text-[#CCC]">
            {evaluation.weaknesses.map((weak, idx) => (
              <li key={idx} className="flex items-start gap-2.5">
                <span className="text-[#E11D48] font-bold font-serif">•</span>
                <span>{weak}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Suggested keywords / missing points */}
      {evaluation.missing_points.length > 0 && (
        <div className="bg-[#111111] border border-[#2A2A2A] p-8">
          <h3 className="text-[10px] font-mono text-[#888] uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#888]" />
            Key Concepts or Terminology Missing
          </h3>
          <div className="flex flex-wrap gap-2">
            {evaluation.missing_points.map((pt, idx) => (
              <span key={idx} className="bg-[#161616] border border-[#2A2A2A] text-slate-300 text-[10px] font-mono px-3 py-1.5 uppercase tracking-wider">
                {pt}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Practical Improvement Tips & Sample Better Response */}
      <div className="bg-[#111111] border border-[#2A2A2A] p-8 shadow-sm">
        <h3 className="text-[11px] font-mono uppercase tracking-[0.2em] text-[#888] mb-4 flex items-center gap-2 border-b border-[#2A2A2A] pb-3">
          <Lightbulb className="w-4 h-4 text-[#38BDF8]" />
          Practical Coach Guidelines
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {evaluation.improvement_suggestions.map((sug, idx) => (
            <div key={idx} className="bg-[#0A0A0A] border border-[#2A2A2A] p-5">
              <div className="text-[10px] font-mono font-bold text-[#38BDF8] uppercase tracking-wider mb-2">Tip #{idx + 1}</div>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">{sug}</p>
            </div>
          ))}
        </div>

        {/* Sample Response toggle block */}
        <div className="border-t border-[#2A2A2A] pt-4">
          <button
            type="button"
            id="toggle-better-answer"
            onClick={() => setShowBetterAnswer(!showBetterAnswer)}
            className="w-full flex items-center justify-between text-slate-300 hover:text-white font-mono uppercase tracking-widest text-[10px] py-1 transition cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#38BDF8]" />
              View Exemplar Response (Gold Standard)
            </span>
            {showBetterAnswer ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showBetterAnswer && (
            <div className="bg-[#0A0A0A] border border-[#2A2A2A] p-5 mt-4 text-xs text-[#CCC] leading-relaxed font-mono whitespace-pre-line">
              {evaluation.sample_better_answer}
            </div>
          )}
        </div>
      </div>

      {/* Adaptive Probing Follow-Up Section (Prompt 4) */}
      {evaluation.follow_up_question && (
        <div className="bg-[#1C160C] border border-[#C27803]/40 p-8">
          <div className="flex flex-wrap items-center gap-2.5 mb-4">
            <span className="bg-[#C27803] text-white text-[9px] font-mono font-black uppercase tracking-widest px-2.5 py-1">
              PROBING FOLLOW-UP CHALLENGE
            </span>
            <span className="text-[10px] text-amber-200 font-mono uppercase tracking-wider">Difficulty: {evaluation.follow_up_difficulty || 'Medium'}</span>
          </div>
          <h4 className="text-xl font-serif italic text-amber-100 leading-relaxed mb-2">
            "{evaluation.follow_up_question}"
          </h4>
          <p className="text-xs text-amber-200/70 leading-normal flex items-start gap-1.5 mb-6">
            <CornerDownRight className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
            <span><strong>Objective:</strong> {evaluation.follow_up_purpose || 'Probe deeper into practical system constraints and decision-making.'}</span>
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <button
              type="button"
              id="btn-answer-followup"
              onClick={() => onAnswerFollowUp(evaluation.follow_up_question!)}
              className="inline-flex items-center justify-center bg-[#C27803] hover:bg-amber-600 text-white text-[10px] font-mono uppercase tracking-widest px-6 py-3.5 cursor-pointer transition border-none"
            >
              Accept Challenge
            </button>
            <button
              type="button"
              id="btn-skip-followup"
              onClick={onNextQuestion}
              className="inline-flex items-center justify-center bg-transparent border border-amber-900/60 hover:border-amber-700 hover:bg-amber-950/20 text-amber-200 text-[10px] font-mono uppercase tracking-widest px-6 py-3.5 cursor-pointer transition"
            >
              Skip & Go Next
            </button>
          </div>
        </div>
      )}

      {/* If there is no follow-up generated (or skipped) */}
      {!evaluation.follow_up_question && (
        <div className="flex justify-end">
          <button
            type="button"
            id="btn-next-question-direct"
            onClick={onNextQuestion}
            className="inline-flex items-center justify-center bg-[#E11D48] hover:bg-rose-700 text-white text-[10px] font-mono uppercase tracking-widest px-8 py-4 font-bold transition border-none cursor-pointer"
          >
            {hasMoreQuestions ? 'Proceed to Next Question' : 'Generate Performance Report'}
          </button>
        </div>
      )}
    </div>
  );
}
