/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Question, AnswerSession } from '../types';
import { Mic, MicOff, Volume2, VolumeX, SkipForward, ArrowRight, Brain, Keyboard, MessageSquare, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface InterviewConsoleProps {
  question: Question;
  isFollowUp: boolean;
  onAnswerSubmit: (answerText: string) => void;
  onSkipQuestion: () => void;
  currentIndex: number;
  totalQuestions: number;
  isSubmitting: boolean;
}

export default function InterviewConsole({
  question,
  isFollowUp,
  onAnswerSubmit,
  onSkipQuestion,
  currentIndex,
  totalQuestions,
  isSubmitting
}: InterviewConsoleProps) {
  const [answer, setAnswer] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [sttSupported, setSttSupported] = useState(true);
  const [errorText, setErrorText] = useState('');
  const recognitionRef = useRef<any>(null);

  // Load custom speech recognition if available
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSttSupported(false);
    } else {
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'en-US';

      rec.onstart = () => {
        setIsRecording(true);
        setErrorText('');
      };

      rec.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          setErrorText('Microphone permission blocked by browser container.');
        } else {
          setErrorText(`Voice error: ${event.error}`);
        }
        setIsRecording(false);
      };

      rec.onend = () => {
        setIsRecording(false);
      };

      rec.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        if (finalTranscript) {
          setAnswer((prev) => {
            const trimmed = prev.trim();
            return trimmed ? `${trimmed} ${finalTranscript}` : finalTranscript;
          });
        }
      };

      recognitionRef.current = rec;
    }

    // Clean up speaking and recording on unmount or question change
    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  // Cancel speaking when question changes, clear input
  useEffect(() => {
    setAnswer('');
    setIsSpeaking(false);
    setErrorText('');
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  }, [question]);

  const toggleRecording = () => {
    if (!sttSupported) {
      setErrorText('Speech-to-Text is not natively supported in this browser version.');
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      try {
        if (isSpeaking) {
          stopSpeaking();
        }
        recognitionRef.current.start();
      } catch (err) {
        console.error(err);
        setErrorText('Failed to start speech recognition. Please retry.');
      }
    }
  };

  const startSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(question.question);
      utterance.rate = 1.05;
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    } else {
      setErrorText('Text-to-Speech is not supported in this browser.');
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setAnswer(e.target.value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRecording) {
      recognitionRef.current.stop();
    }
    stopSpeaking();
    onAnswerSubmit(answer);
  };

  const wordCount = answer.trim() ? answer.trim().split(/\s+/).length : 0;

  // Smart loading messages based on categories
  const [loadingMessage, setLoadingMessage] = useState('Analyzing answer...');
  useEffect(() => {
    if (!isSubmitting) return;

    const messages = [
      'Gemini is grading relevance and response completeness...',
      'Assessing technical accuracy & industry terminology...',
      'Evaluating delivery, structuring, and communication tone...',
      'Formulating actionable improvement tips...',
      'Drafting a senior-level sample response to teach you...',
      'Concocting a custom follow-up challenge...'
    ];

    let index = 0;
    setLoadingMessage(messages[0]);

    const interval = setInterval(() => {
      index = (index + 1) % messages.length;
      setLoadingMessage(messages[index]);
    }, 2800);

    return () => clearInterval(interval);
  }, [isSubmitting]);

  return (
    <div id="interview-console" className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
      {/* Question Details Card (Left Pane on desktop) */}
      <div className="md:col-span-5 bg-[#0F0F0F] text-[#F4F4F4] border border-[#2A2A2A] p-8 flex flex-col justify-between min-h-[380px]">
        <div>
          {/* Header Progress and Badges */}
          <div className="flex flex-col gap-2.5 border-b border-[#2A2A2A] pb-5 mb-5">
            <div className="flex items-center justify-between">
              <span className="bg-[#F4F4F4] text-[#0A0A0A] px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-wider">
                {isFollowUp ? "Adaptive Challenge" : `Question ${currentIndex + 1} of ${totalQuestions}`}
              </span>
              <span className="text-[10px] uppercase tracking-widest text-[#888] font-mono">
                {question.difficulty}
              </span>
            </div>
            <span className="text-[10px] uppercase tracking-widest text-[#888] font-mono font-bold block">
              Category: {question.category}
            </span>
          </div>

          {/* Question Text */}
          <div className="my-6">
            <h3 className="text-3xl sm:text-4xl font-serif italic text-white leading-tight">
              "{question.question}"
            </h3>
          </div>

          {/* Expected Skills Block */}
          <div className="mt-6">
            <div className="text-[9px] font-mono text-[#888] uppercase tracking-[0.2em] mb-2.5">Competencies Tested</div>
            <div className="flex flex-wrap gap-2">
              {question.skills_tested.map((skill, idx) => (
                <span key={idx} className="bg-[#161616] border border-[#2A2A2A] text-slate-300 text-[10px] px-2.5 py-1 font-mono">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* TTS control and estimation */}
        <div className="border-t border-[#2A2A2A] pt-5 mt-8 flex items-center justify-between text-[10px] text-[#888] font-mono uppercase tracking-wider">
          <span>Est. Time: {question.estimated_time}</span>
          <button
            type="button"
            id="btn-speak-question"
            onClick={isSpeaking ? stopSpeaking : startSpeaking}
            className={`text-[9px] uppercase tracking-widest border px-3 py-1.5 cursor-pointer transition-colors ${
              isSpeaking
                ? 'bg-[#E11D48] text-white border-transparent font-bold'
                : 'border-[#444] hover:bg-[#F4F4F4] hover:text-[#0A0A0A] text-[#F4F4F4]'
            }`}
          >
            {isSpeaking ? 'Stop TTS' : 'Read Aloud'}
          </button>
        </div>
      </div>

      {/* Answer Writing Console (Right Pane) */}
      <div className="md:col-span-7 bg-[#111111] border border-[#2A2A2A] p-8 flex flex-col justify-between">
        <form onSubmit={handleSubmit} id="answer-form" className="space-y-6">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-4">
            <h3 className="text-[11px] uppercase tracking-[0.2em] text-[#888] font-bold">
              Your Response
            </h3>
            {/* Word count check */}
            <span className="text-[9px] font-mono bg-[#1C1C1C] border border-[#2A2A2A] text-slate-300 px-2 py-0.5 uppercase tracking-widest">
              {wordCount} words
            </span>
          </div>

          {/* Alert/Error message */}
          {errorText && (
            <div className="bg-red-950/25 border border-red-900/60 text-red-300 p-3.5 rounded-none text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-red-500" />
              <span>{errorText}</span>
            </div>
          )}

          {/* Response text area */}
          <div className="relative">
            <textarea
              id="answer-textarea"
              rows={9}
              required
              disabled={isSubmitting}
              value={answer}
              onChange={handleTextareaChange}
              placeholder="Type your response here or click 'Speak Answer' to dictate with Speech-to-Text..."
              className="w-full bg-[#0A0A0A] border border-[#2A2A2A] focus:border-[#38BDF8] text-[#F4F4F4] placeholder:text-[#555] py-3.5 px-4 text-sm outline-none transition duration-150 font-sans leading-relaxed resize-none"
            />

            {/* Glowing Voice Activity Overlay */}
            {isRecording && (
              <div className="absolute inset-x-0 bottom-4 flex justify-center pointer-events-none">
                <div className="bg-[#0F0F0F] border border-[#38BDF8] text-[#38BDF8] text-[9px] font-mono uppercase tracking-[0.15em] px-4 py-2 flex items-center gap-2.5 shadow-lg shadow-[#38BDF8]/10">
                  <div className="flex gap-1.5 items-center">
                    <div className="w-1 h-3.5 bg-[#38BDF8] animate-pulse"></div>
                    <div className="w-1 h-5 bg-[#38BDF8] opacity-60"></div>
                    <div className="w-1 h-4 bg-[#38BDF8]"></div>
                  </div>
                  <span>AI listening ... speak response</span>
                </div>
              </div>
            )}
          </div>

          {/* Action buttons (Microphone input & Submitting) */}
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pt-2">
            <div className="flex gap-2 w-full sm:w-auto">
              {/* Speak Button */}
              <button
                type="button"
                id="btn-voice-input"
                disabled={isSubmitting}
                onClick={toggleRecording}
                className={`flex-1 sm:flex-none text-[10px] uppercase tracking-widest border px-4 py-3 font-semibold cursor-pointer transition ${
                  isRecording
                    ? 'bg-red-600 border-red-500 text-white shadow-glow-pulse animate-pulse'
                    : 'bg-[#0A0A0A] border-[#444] hover:bg-[#F4F4F4] hover:text-[#0A0A0A] text-[#F4F4F4]'
                }`}
              >
                {isRecording ? 'Stop Speaking' : 'Speak Answer'}
              </button>

              {/* Clear button */}
              {answer && !isSubmitting && (
                <button
                  type="button"
                  id="btn-clear-answer"
                  onClick={() => setAnswer('')}
                  className="bg-[#1C1C1C] border border-[#2D2D2D] text-slate-300 hover:text-white px-4 py-3 text-[10px] uppercase tracking-widest cursor-pointer transition font-mono"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="flex gap-2 w-full sm:w-auto justify-end">
              {/* Skip question */}
              {!isSubmitting && (
                <button
                  type="button"
                  id="btn-skip-question"
                  onClick={onSkipQuestion}
                  className="text-[10px] uppercase tracking-widest border border-[#444] text-[#888] hover:text-white px-4 py-3 cursor-pointer transition"
                >
                  Skip
                </button>
              )}

              {/* Submit answer */}
              <button
                type="submit"
                id="btn-submit-answer"
                disabled={isSubmitting || !answer.trim()}
                className="flex-1 sm:flex-none text-[10px] uppercase tracking-widest bg-[#E11D48] hover:bg-rose-700 disabled:bg-rose-950 disabled:text-rose-400 text-white font-bold px-6 py-3 transition duration-150 cursor-pointer border-none"
              >
                Submit & Evaluate
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Full-screen Loading Overlay for submit evaluation */}
      {isSubmitting && (
        <div className="fixed inset-0 bg-[#0A0A0A]/90 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#111111] border border-[#2A2A2A] p-10 max-w-md w-full text-center shadow-2xl">
            <div className="relative inline-block mb-5">
              <div className="w-16 h-16 border-4 border-[#2A2A2A] border-t-[#38BDF8] rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Brain className="w-6 h-6 text-[#38BDF8] animate-pulse" />
              </div>
            </div>
            <h3 className="text-xl font-serif italic text-white mb-2">Analyzing Performance</h3>
            <p className="text-xs text-slate-400 font-sans h-12 flex items-center justify-center px-4 leading-normal">
              {loadingMessage}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
