/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CandidateProfile } from '../types';
import { Sparkles, User, Briefcase, FileText, Settings, HelpCircle, GraduationCap } from 'lucide-react';
import { motion } from 'motion/react';

interface SetupFormProps {
  onSubmit: (profile: CandidateProfile) => void;
  isLoading: boolean;
}

const PRESETS = [
  {
    name: "Senior Software Engineer (Full Stack)",
    role: "Senior Software Engineer",
    experienceLevel: "Senior" as const,
    interviewType: "Technical" as const,
    questionCount: 5,
    jobDescription: "Looking for a Senior Full Stack Engineer to lead the migration of our core microservices to Node.js and React. Responsibilities include optimizing database queries (PostgreSQL), ensuring high test coverage, designing secure REST/GraphQL APIs, and mentoring junior engineers. Experience with system design and high-scale traffic is a plus.",
    resumeSummary: "8+ years of software development experience specializing in React, TypeScript, Express, and cloud deployments (GCP/AWS). Proven track record of optimizing database queries, reducing API latency by 40%, and leading cross-functional teams of 5-8 developers."
  },
  {
    name: "Technical Product Manager",
    role: "Technical Product Manager",
    experienceLevel: "Lead / Manager" as const,
    interviewType: "Mixed" as const,
    questionCount: 5,
    jobDescription: "We are seeking a TPM to drive the vision and execution of our AI Developer Platform. You will collaborate with engineering to build scalable SDK surfaces, define system requirements, align product roadmaps, manage stakeholder expectations, and measure customer success metrics (DAU, latency, NPS).",
    resumeSummary: "Product leader with an engineering background. 6 years of experience launching SaaS products and developer APIs. Expert in backlog grooming, roadmapping with Jira, conducting user research, and synthesizing technical requirements into clear product specs."
  },
  {
    name: "Junior Frontend Developer",
    role: "Frontend Developer",
    experienceLevel: "Entry Level" as const,
    interviewType: "Technical" as const,
    questionCount: 3,
    jobDescription: "Looking for an energetic Junior Frontend Developer with solid knowledge of React, HTML, CSS, and modern web APIs. You will work closely with designers to implement responsive, pixel-perfect user interfaces, handle form state validation, and consume REST APIs.",
    resumeSummary: "Recent Boot Camp graduate with a Bachelor's in CS. Built 4 responsive React web apps during training. Fluent in CSS Tailwind, TypeScript, state management (Redux/Context), and modern Git workflows."
  },
  {
    name: "Behavioral - Engineering Manager",
    role: "Engineering Manager",
    experienceLevel: "Lead / Manager" as const,
    interviewType: "Behavioral" as const,
    questionCount: 5,
    jobDescription: "Seeking an EM to lead a high-performing infrastructure squad. Responsibilities include talent coaching, career pathing, handling performance reviews, managing technical debt, resolving cross-team conflicts, and orchestrating weekly sprint deliveries.",
    resumeSummary: "EM with 4 years managing engineering teams and 6 years of individual contributor experience. Passionate about continuous integration, psychological safety, and building data-driven agile sprints."
  }
];

export default function SetupForm({ onSubmit, isLoading }: SetupFormProps) {
  const [name, setName] = useState('Jane Doe');
  const [role, setRole] = useState('Senior Software Engineer');
  const [experienceLevel, setExperienceLevel] = useState<CandidateProfile['experienceLevel']>('Senior');
  const [interviewType, setInterviewType] = useState<CandidateProfile['interviewType']>('Mixed');
  const [questionCount, setQuestionCount] = useState(5);
  const [jobDescription, setJobDescription] = useState('');
  const [resumeSummary, setResumeSummary] = useState('');

  const handleApplyPreset = (preset: typeof PRESETS[0]) => {
    setRole(preset.role);
    setExperienceLevel(preset.experienceLevel);
    setInterviewType(preset.interviewType);
    setQuestionCount(preset.questionCount);
    setJobDescription(preset.jobDescription);
    setResumeSummary(preset.resumeSummary);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !role.trim()) return;

    onSubmit({
      name,
      role,
      experienceLevel,
      interviewType,
      questionCount,
      jobDescription,
      resumeSummary
    });
  };

  return (
    <div id="setup-container" className="max-w-4xl mx-auto space-y-6">
      {/* Header section with minimal elegance */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-[#161616] border border-[#2A2A2A] text-[#38BDF8] px-3.5 py-1 text-[10px] uppercase tracking-[0.25em] font-mono mb-4">
          <Sparkles className="w-3.5 h-3.5 animate-pulse" />
          Powered by Gemini 3.5 Flash
        </div>
        <h1 className="text-4xl sm:text-5xl font-serif italic text-white tracking-tight mb-2">
          AI Interview Coach
        </h1>
        <p className="text-slate-400 text-sm max-w-lg mx-auto font-sans leading-relaxed">
          Tailored, adaptive mock interviews with live dialogue diagnostics and a personalized 7-day preparation roadmap.
        </p>
      </div>

      {/* Preset selector bar */}
      <div className="bg-[#111111] border border-[#2A2A2A] p-6">
        <div className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] mb-4 flex items-center gap-2 border-b border-[#2A2A2A] pb-2">
          <Settings className="w-4 h-4 text-[#888]" />
          Select a Mock Interview Preset
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {PRESETS.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              id={`preset-${idx}`}
              onClick={() => handleApplyPreset(preset)}
              className="text-left text-xs bg-[#0A0A0A] border border-[#222] hover:border-[#38BDF8] hover:bg-[#161616] p-3.5 transition duration-150 cursor-pointer"
            >
              <div className="font-serif italic text-[#F4F4F4] truncate">{preset.name}</div>
              <div className="text-[10px] text-[#888] mt-1 font-mono uppercase tracking-wider">{preset.interviewType} • {preset.experienceLevel}</div>
            </button>
          ))}
        </div>
      </div>

      <form id="setup-form" onSubmit={handleSubmit} className="bg-[#111111] border border-[#2A2A2A] p-6 sm:p-10 space-y-6">
        <h2 className="text-xl font-serif italic text-white mb-6 flex items-center gap-2.5 border-b border-[#2A2A2A] pb-4">
          <User className="w-5 h-5 text-[#38BDF8]" />
          Candidate Profile & Parameters
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Candidate Name */}
          <div>
            <label className="block text-[10px] font-bold text-[#888] uppercase tracking-[0.25em] mb-2">
              Candidate Name
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-[#555]">
                <User className="w-4 h-4" />
              </span>
              <input
                type="text"
                id="candidate-name"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="E.g., Jane Doe"
                className="w-full bg-[#0A0A0A] border border-[#2A2A2A] focus:border-[#38BDF8] text-[#F4F4F4] placeholder:text-[#555] py-2.5 pl-10 pr-4 text-sm outline-none transition duration-150 font-sans"
              />
            </div>
          </div>

          {/* Target Role */}
          <div>
            <label className="block text-[10px] font-bold text-[#888] uppercase tracking-[0.25em] mb-2">
              Target Job Role
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-[#555]">
                <Briefcase className="w-4 h-4" />
              </span>
              <input
                type="text"
                id="target-role"
                required
                value={role}
                onChange={(e) => setRole(e.target.value)}
                placeholder="E.g., Senior Full Stack Developer"
                className="w-full bg-[#0A0A0A] border border-[#2A2A2A] focus:border-[#38BDF8] text-[#F4F4F4] placeholder:text-[#555] py-2.5 pl-10 pr-4 text-sm outline-none transition duration-150 font-sans"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Experience Level */}
          <div>
            <label className="block text-[10px] font-bold text-[#888] uppercase tracking-[0.25em] mb-2">
              Experience Level
            </label>
            <select
              id="experience-level"
              value={experienceLevel}
              onChange={(e) => setExperienceLevel(e.target.value as CandidateProfile['experienceLevel'])}
              className="w-full bg-[#0A0A0A] border border-[#2A2A2A] focus:border-[#38BDF8] text-[#F4F4F4] py-2.5 px-3.5 text-sm outline-none transition duration-150 font-sans"
            >
              <option value="Entry Level" className="bg-[#0A0A0A]">Entry Level (0-2 years)</option>
              <option value="Mid Level" className="bg-[#0A0A0A]">Mid Level (2-5 years)</option>
              <option value="Senior" className="bg-[#0A0A0A]">Senior (5+ years)</option>
              <option value="Lead / Manager" className="bg-[#0A0A0A]">Lead / Manager (8+ years)</option>
            </select>
          </div>

          {/* Interview Type */}
          <div>
            <label className="block text-[10px] font-bold text-[#888] uppercase tracking-[0.25em] mb-2">
              Interview Focus
            </label>
            <select
              id="interview-type"
              value={interviewType}
              onChange={(e) => setInterviewType(e.target.value as CandidateProfile['interviewType'])}
              className="w-full bg-[#0A0A0A] border border-[#2A2A2A] focus:border-[#38BDF8] text-[#F4F4F4] py-2.5 px-3.5 text-sm outline-none transition duration-150 font-sans"
            >
              <option value="Technical" className="bg-[#0A0A0A]">Technical (Coding, System Design)</option>
              <option value="Behavioral" className="bg-[#0A0A0A]">Behavioral (STAR Method)</option>
              <option value="Mixed" className="bg-[#0A0A0A]">Mixed (Well-rounded review)</option>
            </select>
          </div>

          {/* Questions Count */}
          <div>
            <label className="block text-[10px] font-bold text-[#888] uppercase tracking-[0.25em] mb-2">
              Number of Questions
            </label>
            <select
              id="question-count"
              value={questionCount}
              onChange={(e) => setQuestionCount(Number(e.target.value))}
              className="w-full bg-[#0A0A0A] border border-[#2A2A2A] focus:border-[#38BDF8] text-[#F4F4F4] py-2.5 px-3.5 text-sm outline-none transition duration-150 font-sans"
            >
              <option value={3} className="bg-[#0A0A0A]">3 Questions (Fast Sandbox)</option>
              <option value={5} className="bg-[#0A0A0A]">5 Questions (Standard Practice)</option>
              <option value={10} className="bg-[#0A0A0A]">10 Questions (Full Mock)</option>
            </select>
          </div>
        </div>

        {/* Job Description */}
        <div>
          <label className="block text-[10px] font-bold text-[#888] uppercase tracking-[0.25em] mb-2 flex items-center gap-1">
            <GraduationCap className="w-4 h-4 text-[#888]" />
            Target Job Description (Optional)
          </label>
          <textarea
            id="job-description"
            rows={4}
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            placeholder="Paste the target job post requirements here. Gemini will scan this to generate exact real-world scenario questions..."
            className="w-full bg-[#0A0A0A] border border-[#2A2A2A] focus:border-[#38BDF8] text-[#F4F4F4] placeholder:text-[#555] py-2.5 px-3.5 text-sm outline-none transition duration-150 font-sans"
          />
        </div>

        {/* Resume Summary */}
        <div>
          <label className="block text-[10px] font-bold text-[#888] uppercase tracking-[0.25em] mb-2 flex items-center gap-1">
            <FileText className="w-4 h-4 text-[#888]" />
            Your Resume Summary or Core Skills (Optional)
          </label>
          <textarea
            id="resume-summary"
            rows={4}
            value={resumeSummary}
            onChange={(e) => setResumeSummary(e.target.value)}
            placeholder="Paste your key resume bullet points, frameworks, or past projects. Gemini will cross-reference this to push your expertise boundaries..."
            className="w-full bg-[#0A0A0A] border border-[#2A2A2A] focus:border-[#38BDF8] text-[#F4F4F4] placeholder:text-[#555] py-2.5 px-3.5 text-sm outline-none transition duration-150 font-sans"
          />
        </div>

        {/* Submit button with loader */}
        <div className="flex justify-end pt-4">
          <button
            type="submit"
            id="btn-generate-questions"
            disabled={isLoading || !name.trim() || !role.trim()}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-[#E11D48] hover:bg-rose-700 disabled:bg-rose-950 disabled:text-rose-400 text-white font-bold uppercase tracking-widest text-xs px-8 py-3.5 transition duration-150 focus:outline-none cursor-pointer"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>Assembling Question Track...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Start Mock Interview</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
