/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Report, CandidateProfile, AnswerSession } from '../types';
import { Award, CheckCircle2, AlertCircle, Copy, BookOpen, Calendar, RefreshCcw, Landmark, User, Zap, Star, ShieldAlert, Check } from 'lucide-react';
import { motion } from 'motion/react';

interface ReportDashboardProps {
  report: Report;
  profile: CandidateProfile;
  answers: AnswerSession[];
  onRestart: () => void;
}

export default function ReportDashboard({ report, profile, answers, onRestart }: ReportDashboardProps) {
  const [activeDay, setActiveDay] = useState<string>('Day 1');
  const [copied, setCopied] = useState(false);

  // Hiring recommendation styling
  const getRecommendationStyle = (rec: string) => {
    switch (rec) {
      case 'Strong Hire':
        return 'text-[#38BDF8] bg-[#0F172A] border-[#38BDF8]/40';
      case 'Hire':
        return 'text-[#38BDF8] bg-[#0F172A]/50 border-[#38BDF8]/20';
      case 'Borderline':
        return 'text-amber-400 bg-amber-950/20 border-amber-800/40';
      default:
        return 'text-[#E11D48] bg-red-950/20 border-red-900/40';
    }
  };

  const getRatingStyle = (rating: string) => {
    switch (rating) {
      case 'Excellent':
        return 'text-[#38BDF8] bg-[#0A1A22] border border-[#38BDF8]/30';
      case 'Good':
        return 'text-[#38BDF8]/90 bg-[#0A1A22]/50 border border-[#38BDF8]/20';
      case 'Average':
        return 'text-amber-400 bg-amber-950/20 border border-amber-900/30';
      default:
        return 'text-[#E11D48] bg-red-950/20 border border-red-900/30';
    }
  };

  // Copy report as markdown
  const handleCopyMarkdown = () => {
    const md = `
# AI Interview Coach - Performance Report Card
**Candidate Name:** ${profile.name}
**Target Role:** ${profile.role}
**Experience Level:** ${profile.experienceLevel}
**Focus Focus:** ${profile.interviewType}

## Core Evaluation Stats
- **Overall Cumulative Score:** ${report.overall_score}/10
- **Rating:** ${report.overall_rating}
- **Hiring Recommendation:** ${report.hiring_recommendation}

## Performance Breakdown
- **Technical Knowledge:** ${report.performance_breakdown.technical_knowledge}
- **Communication Skills:** ${report.performance_breakdown.communication_skills}
- **Problem Solving:** ${report.performance_breakdown.problem_solving}
- **Confidence:** ${report.performance_breakdown.confidence}
- **Behavioral Readiness:** ${report.performance_breakdown.behavioral_readiness}

## Key Strengths
${report.key_strengths.map(s => `- ${s}`).join('\n')}

## Areas to Improve
${report.areas_to_improve.map(a => `- ${a}`).join('\n')}

## Recommended Study Materials
${report.recommended_resources.map(r => `- ${r}`).join('\n')}

## 7-Day Personalized Improvement Roadmap
${report.action_plan_7_day.map(d => `
### ${d.day}: ${d.focus}
${d.tasks.map(t => `- [ ] ${t}`).join('\n')}
`).join('\n')}
    `.trim();

    navigator.clipboard.writeText(md).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div id="report-dashboard" className="max-w-4xl mx-auto space-y-8 pb-12">
      {/* Header card with big score meter */}
      <div className="bg-[#111111] border border-[#2A2A2A] p-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        {/* Left Side: Score ring meter */}
        <div className="md:col-span-4 flex flex-col items-center text-center">
          <div className="relative flex items-center justify-center w-40 h-40">
            {/* SVG circle track */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="80"
                cy="80"
                r="68"
                className="stroke-[#222]"
                strokeWidth="10"
                fill="transparent"
              />
              <circle
                cx="80"
                cy="80"
                r="68"
                className="stroke-[#38BDF8] transition-all duration-1000"
                strokeWidth="10"
                strokeDasharray={2 * Math.PI * 68}
                strokeDashoffset={2 * Math.PI * 68 * (1 - report.overall_score / 10)}
                strokeLinecap="square"
                fill="transparent"
              />
            </svg>
            {/* Internal text */}
            <div className="absolute flex flex-col items-center">
              <span className="text-4xl font-bold text-white font-mono">{report.overall_score.toFixed(1)}</span>
              <span className="text-[9px] text-[#888] font-mono uppercase tracking-[0.2em] mt-0.5">Rating</span>
            </div>
          </div>
          <div className={`mt-4 px-3 py-1 text-[10px] uppercase tracking-wider font-mono font-bold ${getRatingStyle(report.overall_rating)}`}>
            {report.overall_rating} Rating
          </div>
        </div>

        {/* Right Side: Candidate metadata and hiring verdict */}
        <div className="md:col-span-8 space-y-5">
          <div>
            <span className="text-[10px] font-mono text-[#888] uppercase tracking-[0.2em] block">Diagnostic Summary Report</span>
            <h1 className="text-3xl sm:text-4xl font-serif italic text-white leading-tight mt-1.5">
              {profile.name} Report Card
            </h1>
            <p className="text-xs text-[#888] font-mono uppercase tracking-widest mt-1">
              Position: <strong className="text-white">{profile.role} ({profile.experienceLevel})</strong>
            </p>
          </div>

          {/* Hiring Status Badge */}
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
            <span className="text-[10px] text-[#888] font-mono uppercase tracking-widest font-bold">Recommendation:</span>
            <div className={`px-4 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider border ${getRecommendationStyle(report.hiring_recommendation)}`}>
              {report.hiring_recommendation}
            </div>
          </div>

          {/* Quick buttons */}
          <div className="flex flex-wrap gap-2.5 pt-1">
            <button
              type="button"
              id="btn-copy-markdown"
              onClick={handleCopyMarkdown}
              className="text-[10px] uppercase tracking-widest border border-[#444] hover:bg-[#F4F4F4] hover:text-[#0A0A0A] text-[#F4F4F4] px-5 py-3 cursor-pointer transition font-mono"
            >
              {copied ? 'Copied to Clipboard' : 'Copy Markdown Report'}
            </button>

            <button
              type="button"
              id="btn-restart-interview"
              onClick={onRestart}
              className="text-[10px] uppercase tracking-widest bg-[#E11D48] hover:bg-rose-700 text-white font-bold px-5 py-3 transition cursor-pointer border-none"
            >
              Start New Session
            </button>
          </div>
        </div>
      </div>

      {/* Skills breakdown grid */}
      <div className="bg-[#111111] border border-[#2A2A2A] p-8">
        <h2 className="text-xl font-serif italic text-white mb-6">
          Qualitative Breakdown
        </h2>

        <div className="space-y-5">
          {/* Technical knowledge card */}
          <div className="grid grid-cols-1 md:grid-cols-4 border-b border-[#2A2A2A] pb-5 gap-2 md:gap-4 items-start">
            <div className="text-[10px] font-bold text-[#888] uppercase font-mono md:pt-1">Technical Knowledge</div>
            <p className="md:col-span-3 text-sm text-slate-300 leading-relaxed">
              {report.performance_breakdown.technical_knowledge}
            </p>
          </div>

          {/* Communication card */}
          <div className="grid grid-cols-1 md:grid-cols-4 border-b border-[#2A2A2A] pb-5 gap-2 md:gap-4 items-start">
            <div className="text-[10px] font-bold text-[#888] uppercase font-mono md:pt-1">Communication Skills</div>
            <p className="md:col-span-3 text-sm text-slate-300 leading-relaxed">
              {report.performance_breakdown.communication_skills}
            </p>
          </div>

          {/* Problem Solving card */}
          <div className="grid grid-cols-1 md:grid-cols-4 border-b border-[#2A2A2A] pb-5 gap-2 md:gap-4 items-start">
            <div className="text-[10px] font-bold text-[#888] uppercase font-mono md:pt-1">Problem Solving</div>
            <p className="md:col-span-3 text-sm text-slate-300 leading-relaxed">
              {report.performance_breakdown.problem_solving}
            </p>
          </div>

          {/* Confidence card */}
          <div className="grid grid-cols-1 md:grid-cols-4 border-b border-[#2A2A2A] pb-5 gap-2 md:gap-4 items-start">
            <div className="text-[10px] font-bold text-[#888] uppercase font-mono md:pt-1">Confidence under pressure</div>
            <p className="md:col-span-3 text-sm text-slate-300 leading-relaxed">
              {report.performance_breakdown.confidence}
            </p>
          </div>

          {/* Behavioral readiness card */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-2 md:gap-4 items-start">
            <div className="text-[10px] font-bold text-[#888] uppercase font-mono md:pt-1">Behavioral Readiness</div>
            <p className="md:col-span-3 text-sm text-slate-300 leading-relaxed">
              {report.performance_breakdown.behavioral_readiness}
            </p>
          </div>
        </div>
      </div>

      {/* Strengths and areas for improvement split dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Key Strengths */}
        <div className="bg-[#111111] border border-[#2A2A2A] p-8">
          <h3 className="text-[11px] font-mono uppercase tracking-[0.2em] text-[#888] mb-5 flex items-center gap-2 border-b border-[#2A2A2A] pb-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            Top 3 High Impact Strengths
          </h3>
          <ol className="space-y-4">
            {report.key_strengths.map((strength, idx) => (
              <li key={idx} className="flex gap-3">
                <span className="w-5 h-5 bg-[#0A1A22] text-[#38BDF8] border border-[#38BDF8]/20 flex items-center justify-center text-[10px] font-mono font-bold shrink-0 mt-0.5">
                  {idx + 1}
                </span>
                <span className="text-sm text-slate-300 leading-relaxed">{strength}</span>
              </li>
            ))}
          </ol>
        </div>

        {/* Top 3 Areas To Improve */}
        <div className="bg-[#111111] border border-[#2A2A2A] p-8">
          <h3 className="text-[11px] font-mono uppercase tracking-[0.2em] text-[#888] mb-5 flex items-center gap-2 border-b border-[#2A2A2A] pb-3">
            <ShieldAlert className="w-4 h-4 text-amber-500" />
            Critical Areas for Growth
          </h3>
          <ol className="space-y-4">
            {report.areas_to_improve.map((area, idx) => (
              <li key={idx} className="flex gap-3">
                <span className="w-5 h-5 bg-red-950/40 text-[#E11D48] border border-red-900/30 flex items-center justify-center text-[10px] font-mono font-bold shrink-0 mt-0.5">
                  {idx + 1}
                </span>
                <span className="text-sm text-slate-300 leading-relaxed">{area}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>

      {/* Recommended study materials */}
      {report.recommended_resources.length > 0 && (
        <div className="bg-[#111111] border border-[#2A2A2A] p-8">
          <h3 className="text-[10px] font-mono text-[#888] uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#888]" />
            Recommended Study & Training Materials
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {report.recommended_resources.map((res, idx) => (
              <div key={idx} className="bg-[#0A0A0A] border border-[#2A2A2A] p-4 flex gap-3">
                <span className="text-[#38BDF8] font-mono text-sm">#{(idx + 1).toString().padStart(2, '0')}</span>
                <p className="text-xs font-mono tracking-wide text-slate-300 leading-normal">
                  {res}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Interactive 7-Day Action Plan Timeline */}
      <div className="bg-[#111111] border border-[#2A2A2A] p-8">
        <h2 className="text-xl font-serif italic text-white mb-6">
          7-Day Training Roadmap
        </h2>

        {/* Timeline tab header selector */}
        <div className="flex border-b border-[#2A2A2A] overflow-x-auto pb-3 gap-2 scrollbar-none">
          {report.action_plan_7_day.map((d) => (
            <button
              key={d.day}
              type="button"
              id={`day-tab-${d.day.replace(' ', '')}`}
              onClick={() => setActiveDay(d.day)}
              className={`px-4 py-2.5 text-[9px] font-mono font-bold uppercase tracking-wider transition ${
                activeDay === d.day
                  ? 'bg-[#F4F4F4] text-[#0A0A0A]'
                  : 'bg-[#161616] border border-[#2A2A2A] text-slate-400 hover:text-white'
              }`}
            >
              {d.day}
            </button>
          ))}
        </div>

        {/* Active training day task board */}
        <div className="pt-6">
          {report.action_plan_7_day.map((d) => {
            if (d.day !== activeDay) return null;
            return (
              <div key={d.day} id={`day-content-${d.day.replace(' ', '')}`} className="space-y-5 animate-fadeIn">
                <div className="bg-[#0A0A0A] border border-[#2A2A2A] p-5">
                  <span className="text-[9px] font-mono font-bold text-[#38BDF8] uppercase tracking-[0.2em]">Daily Core Concentration Focus</span>
                  <h4 className="text-base font-serif italic text-white mt-1">
                    {d.focus}
                  </h4>
                </div>

                <div className="space-y-3">
                  <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-[0.2em] block">Required Training Tasks</span>
                  <div className="grid grid-cols-1 gap-2.5">
                    {d.tasks.map((task, idx) => (
                      <div key={idx} className="flex border border-[#2A2A2A] p-4 bg-[#0A0A0A] items-start gap-3.5">
                        <input
                          type="checkbox"
                          id={`task-${d.day.replace(' ', '')}-${idx}`}
                          className="w-4 h-4 rounded-none border-[#444] bg-transparent text-[#E11D48] focus:ring-0 focus:ring-offset-0 mt-0.5 shrink-0"
                        />
                        <label
                          htmlFor={`task-${d.day.replace(' ', '')}-${idx}`}
                          className="text-xs text-slate-300 leading-normal select-none font-sans cursor-pointer"
                        >
                          {task}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
