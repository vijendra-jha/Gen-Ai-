/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize Gemini SDK with telemetry header as required
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

app.use(express.json({ limit: '10mb' }));

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", hasApiKey: !!apiKey });
});

// Endpoint: Generate Interview Questions (Prompt 1)
app.post("/api/generate-questions", async (req, res) => {
  try {
    const { profile } = req.body;
    if (!profile) {
      return res.status(400).json({ error: "Candidate profile is required." });
    }

    if (!apiKey) {
      return res.status(500).json({ error: "Gemini API key is not configured in the environment." });
    }

    const count = profile.questionCount || 5;
    const prompt = `You are an experienced Senior Technical Interviewer, Hiring Manager, and Talent Assessment Specialist.
Generate a structured interview question set tailored for a candidate with the following profile:

- Role: ${profile.role}
- Experience Level: ${profile.experienceLevel}
- Interview Type: ${profile.interviewType}
- Target Job Description: ${profile.jobDescription || 'Standard requirements for this role'}
- Resume Summary: ${profile.resumeSummary || 'Standard background for this experience level'}

Requirements:
1. Generate exactly ${count} interview questions.
2. Ensure the question difficulty is appropriate for the experience level: ${profile.experienceLevel}.
3. Progress from easier warmups to more challenging scenario-based or deep architectural questions.
4. Include a solid mix of:
   - Technical core questions (theoretical understanding, platform details, database indexing, API structures, etc.)
   - Behavioral / Situational questions (assessing culture fit, leadership, teamwork under pressure, resolving conflict)
   - Problem-solving / Design questions (scalable systems, trade-offs, algorithms or design patterns)
5. Keep the phrasing highly professional, mimicking hiring managers at top tech companies. Do not write filler text.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING, description: "The actual interview question text" },
                  category: { type: Type.STRING, description: "Technical, Behavioral, Situational, or Problem-Solving" },
                  difficulty: { type: Type.STRING, description: "Must be Easy, Medium, or Hard" },
                  skills_tested: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "Specific skills or competencies evaluated by this question"
                  },
                  expected_topics: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "Key words, frameworks, or concepts that the candidate should ideally mention in their answer"
                  },
                  estimated_time: { type: Type.STRING, description: "Suggested response duration, e.g., '3-5 minutes'" }
                },
                required: ["question", "category", "difficulty", "skills_tested", "expected_topics", "estimated_time"]
              }
            }
          },
          required: ["questions"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response content generated from Gemini.");
    }

    const data = JSON.parse(text);
    res.json(data);
  } catch (error: any) {
    console.error("Error in /api/generate-questions:", error);
    res.status(500).json({ error: error.message || "Failed to generate interview questions." });
  }
});

// Endpoint: Evaluate Answer & Generate Follow-up (Prompts 2, 3, 4)
app.post("/api/evaluate-answer", async (req, res) => {
  try {
    const { question, answer, previousContext } = req.body;
    if (!question || answer === undefined) {
      return res.status(400).json({ error: "Question and candidate answer are required." });
    }

    if (!apiKey) {
      return res.status(500).json({ error: "Gemini API key is not configured in the environment." });
    }

    const prompt = `You are a Senior Technical Interviewer and Career Coach. Evaluate the candidate's response to the interview question below.

Question:
"${question}"

Candidate's Answer:
"${answer || '[No Answer Provided / Skipped]'}"

${previousContext ? `Previous interview conversation history:\n${previousContext}\n` : ''}

Evaluate the candidate's response thoroughly. Be constructive, strict, yet encouraging. Assess the response based on:
1. Relevance (1-10)
2. Technical Accuracy (1-10)
3. Communication Quality (1-10)
4. Completeness (1-10)
5. Problem-Solving Ability (1-10)
6. Confidence & Clarity (1-10)

Also, formulate a high-quality dynamic follow-up question (PROMPT 4) to probe deeper.
- The follow-up question must directly relate to what they said in their answer.
- It should explore the depth of their understanding, challenge their assumptions, ask about a trade-off, or ask how they would apply it in a different real-world context.
- Avoid repeating concepts already answered.
- If they didn't answer or skipped, ask a related alternative question to encourage them.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overall_score: { type: Type.INTEGER, description: "Calculated average score of all dimensions (1 to 10)" },
            dimension_scores: {
              type: Type.OBJECT,
              properties: {
                relevance: { type: Type.INTEGER, description: "How relevant was the answer (1-10)" },
                technical_accuracy: { type: Type.INTEGER, description: "How accurate was the technical content (1-10)" },
                communication: { type: Type.INTEGER, description: "Quality of structure and delivery (1-10)" },
                completeness: { type: Type.INTEGER, description: "Coverage of expected talking points (1-10)" },
                problem_solving: { type: Type.INTEGER, description: "How well they analyze and tackle the scenario (1-10)" },
                confidence: { type: Type.INTEGER, description: "Clarity and confidence in response (1-10)" }
              },
              required: ["relevance", "technical_accuracy", "communication", "completeness", "problem_solving", "confidence"]
            },
            strengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "What the candidate answered well (at least 2 points)"
            },
            weaknesses: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Specific gaps, communication issues, or incorrect facts (at least 2 points)"
            },
            missing_points: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Specific terms, concepts, or details they should have mentioned to elevate their answer"
            },
            improvement_suggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly 3 highly practical improvement tips for this specific question"
            },
            sample_better_answer: {
              type: Type.STRING,
              description: "A concise, professional sample response demonstrating an excellent answer"
            },
            readiness_level: {
              type: Type.STRING,
              description: "Rating for this question, e.g. Excellent (9-10), Good (7-8), Average (5-6), Weak (3-4), Poor (1-2)"
            },
            follow_up_question: {
              type: Type.STRING,
              description: "A dynamic probing follow-up question related to their response"
            },
            follow_up_purpose: {
              type: Type.STRING,
              description: "Why we are asking this follow-up (e.g., 'Probe deeper into memory management trade-offs')"
            },
            follow_up_difficulty: {
              type: Type.STRING,
              description: "Difficulty of follow-up (Easy, Medium, Hard)"
            }
          },
          required: [
            "overall_score", "dimension_scores", "strengths", "weaknesses", "missing_points",
            "improvement_suggestions", "sample_better_answer", "readiness_level",
            "follow_up_question", "follow_up_purpose", "follow_up_difficulty"
          ]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response content generated from Gemini.");
    }

    const data = JSON.parse(text);
    res.json(data);
  } catch (error: any) {
    console.error("Error in /api/evaluate-answer:", error);
    res.status(500).json({ error: error.message || "Failed to evaluate answer." });
  }
});

// Endpoint: Generate Final Report (Prompt 5)
app.post("/api/generate-report", async (req, res) => {
  try {
    const { profile, answers } = req.body;
    if (!profile || !answers || !Array.isArray(answers)) {
      return res.status(400).json({ error: "Profile and list of session answers are required." });
    }

    if (!apiKey) {
      return res.status(500).json({ error: "Gemini API key is not configured in the environment." });
    }

    const transcript = answers.map((turn: any, index: number) => {
      const qText = turn.question.question;
      const category = turn.question.category;
      const ansText = turn.answer;
      const score = turn.evaluation ? turn.evaluation.overall_score : 'N/A';
      return `[Question ${index + 1}] (${category})
Question: ${qText}
Candidate Answer: ${ansText || '[Skipped/No answer]'}
Score Given: ${score}/10`;
    }).join("\n\n");

    const prompt = `You are a Senior Career Coach and Talent Assessment Specialist.
Generate a comprehensive, highly personalized Interview Report card and improvement plan for the candidate.

Candidate Profile:
- Name: ${profile.name}
- Target Role: ${profile.role}
- Experience Level: ${profile.experienceLevel}

Interview Transcript and Scores:
${transcript}

Requirements:
1. Provide a rigorous, consolidated overall interview score (1.0 - 10.0 scale) and rating (Excellent / Good / Average / Needs Improvement).
2. Write a detailed, realistic narrative evaluation for each core professional skill:
   - Technical Knowledge
   - Communication Skills
   - Problem Solving
   - Confidence
   - Behavioral Readiness
3. Extract exactly 3 key strengths.
4. Extract exactly 3 clear areas to improve.
5. Provide 3 specific learning resources (courses, books, documentations, design guides).
6. Give a firm Hiring Recommendation: "Strong Hire", "Hire", "Borderline", or "Not Yet Ready".
7. Deliver a highly structured, actionable 7-day personalized action plan roadmap. Each day must outline a precise focus area and 2-3 step-by-step tasks to complete.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overall_score: { type: Type.NUMBER, description: "Aggregate score between 1.0 and 10.0" },
            overall_rating: { type: Type.STRING, description: "Must be Excellent, Good, Average, or Needs Improvement" },
            performance_breakdown: {
              type: Type.OBJECT,
              properties: {
                technical_knowledge: { type: Type.STRING, description: "Detailed summary of technical strengths and gaps" },
                communication_skills: { type: Type.STRING, description: "Evaluation of articulation, conciseness, and flow" },
                problem_solving: { type: Type.STRING, description: "Ability to evaluate trade-offs, architecture, and edge cases" },
                confidence: { type: Type.STRING, description: "Delivery, assurance, and handling of pressure" },
                behavioral_readiness: { type: Type.STRING, description: "STAR method usage, alignment with leadership principles" }
              },
              required: ["technical_knowledge", "communication_skills", "problem_solving", "confidence", "behavioral_readiness"]
            },
            key_strengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly 3 distinct, candidate-specific strengths from the transcript"
            },
            areas_to_improve: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly 3 distinct, specific improvements they must work on"
            },
            recommended_resources: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly 3 high-quality study materials, documentation references, or courses"
            },
            hiring_recommendation: {
              type: Type.STRING,
              description: "Must be Strong Hire, Hire, Borderline, or Not Yet Ready"
            },
            action_plan_7_day: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  day: { type: Type.STRING, description: "E.g., 'Day 1'" },
                  focus: { type: Type.STRING, description: "Focus area for this day" },
                  tasks: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Specific steps to carry out" }
                },
                required: ["day", "focus", "tasks"]
              },
              description: "A comprehensive 7-day personalized training program"
            }
          },
          required: [
            "overall_score", "overall_rating", "performance_breakdown", "key_strengths",
            "areas_to_improve", "recommended_resources", "hiring_recommendation", "action_plan_7_day"
          ]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response content generated from Gemini.");
    }

    const data = JSON.parse(text);
    res.json(data);
  } catch (error: any) {
    console.error("Error in /api/generate-report:", error);
    res.status(500).json({ error: error.message || "Failed to generate interview report." });
  }
});

// Configure Vite or Static Asset serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in DEVELOPMENT mode with Vite Middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in PRODUCTION mode with static file serving...");
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AI Interview Coach server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
